import Tabela from "./Tabela";
export default Tabela
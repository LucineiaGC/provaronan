// Importa as bibliotecas e componentes necessários do React
import React, { useState, useEffect } from 'react';
import './Formulario.css'; // Importa um arquivo de estilo específico para este componente

// Declaração do componente funcional Formulario
const Formulario = ({ campos, onSubmit, itemSelecionado, onUpdate }) => {
  // Estado local para armazenar os dados do formulário
  const [dadosDoFormulario, setDadosDoFormulario] = useState({});

  // Função para lidar com a mudança nos campos do formulário
  const eventoChange = (campo, valor) => {
    setDadosDoFormulario({
      ...dadosDoFormulario,
      [campo]: valor,
    });
  };

  // Função para lidar com a submissão do formulário
  const eventoSubmit = (e) => {
    // Evita o comportamento padrão do formulário (pode ser removido)
    //e.preventDefault();

    // Verifica se há um item selecionado para determinar se é uma atualização ou criação
    if (itemSelecionado) {
      onUpdate(dadosDoFormulario); // Chama a função onUpdate para atualizar um item existente
    } else {
      onSubmit(dadosDoFormulario); // Chama a função onSubmit para criar um novo item
    }
  };

  // Efeito que é acionado quando o itemSelecionado muda
  useEffect(() => {
    if (itemSelecionado) {
      // Se houver um item selecionado, preenche o formulário com seus dados
      setDadosDoFormulario(itemSelecionado.resultado[0]);
      console.log(dadosDoFormulario); // Log para verificar os dados do formulário (pode ser removido)
    }
  }, [itemSelecionado]);

  // Renderização do componente
  // Renderização do componente
return (
  <form onSubmit={eventoSubmit}>
    {campos.map((campo) => (
      <div key={campo.nome} className='divForm'>
        {/* Rótulo do campo */}
        <label className='largura' htmlFor={campo.nome}>
          {campo.label}
        </label>
        
        {/* Input do formulário */}
        <input
          id={campo.nome}  // Adiciona um id associado ao campo de entrada
          type={campo.tipo}
          value={dadosDoFormulario[campo.nome] || ''}
          onChange={(e) => eventoChange(campo.nome, e.target.value)}
        />
      </div>
    ))}
    {/* Botão de envio do formulário */}
    <button type="submit">Salvar</button>
  </form>
);
};
// Exporta o componente para ser utilizado em outros lugares
export default Formulario;

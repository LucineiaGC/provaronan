// Importação das bibliotecas e componentes necessários do React
import React, { useState, useEffect } from 'react';
import './CadastroUsuarios.css'; // Importa um arquivo de estilo específico para este componente
import Formulario from '../../components/Formulario'; // Importa um componente de formulário
import api from '../../services/api'; // Importa um módulo que lida com chamadas à API
import Tabela from '../../Components/Tabela'; // Importa um componente de tabela

// Definição do componente funcional CadastroUsuario
const CadastroUsuario = () => {
  // Estados locais do componente utilizando hooks
  //estados guardam as informações, onde o useState cria eles
  const [mensagem, setMensagem] = useState(''); // Estado para mensagens de feedback
  const [usuarios, setUsuarios] = useState([]); // Estado para armazenar a lista de Usuario
  const [itemSelecionado, setItemSelecionado] = useState(null); // Estado para armazenar um item selecionado da tabela

  // Estados para senhas
  const [confirmarSenha, setConfirmarSenha] = useState('');

  // Função para validar senhas
  const validarSenhas = (senha, confirmarSenha) => {
    return senha === confirmarSenha;
  };

  // Estrutura do formulário (campos) e das colunas da tabela
  //crio lista para mandar para a API 
  const listaForm = [
    { nome: 'nome', label: 'Nome', tipo: 'text' },
    { nome: 'email', label: 'E-Mail', tipo: 'email' },
    { nome: 'anoNascimento', label: 'Ano de Nascimento', tipo: 'number' },
    { nome: 'senha', label: 'Senha', tipo: 'password' },
    { nome: 'confirmarSenha', label: 'Confirmar Senha', tipo: 'password' },
  ];

  //colunas que a tabela irá ter
  const colunasUsuarios = ['id', 'nome', 'email', 'senha', 'anoNascimento'];

  // Função assíncrona para enviar um formulário e gravar um novo Usuario
  const enviarFormulario = async (dadosDoFormulario) => {
    const { senha, confirmarSenha, ...outrosDados } = dadosDoFormulario;
  
    // Verifica se as senhas são iguais
    if (!validarSenhas(senha, confirmarSenha)) {
      setMensagem('As senhas não são iguais');
      return;
    }
  
    try {
      // Certifique-se de incluir a senha no objeto a ser enviado para a API
      await api.gravarUsuario({ ...outrosDados, senha });
      setMensagem('Usuário cadastrado com sucesso');
    } catch (error) {
      console.error('Erro ao cadastrar o usuário:', error.message);
      setMensagem('Erro ao cadastrar o usuário');
    }
  };
  

  // Função assíncrona para editar um formulário e atualizar um Usuario existente
  const editarFormulario = async (dadosDoFormulario) => {
    const { senha, confirmarSenha, ...outrosDados } = dadosDoFormulario;
  
    // Verifica se as senhas são iguais
    if (!validarSenhas(senha, confirmarSenha)) {
      setMensagem('As senhas não são iguais');
      return;
    }
  
    try {
      // Certifique-se de incluir a senha no objeto a ser enviado para a API
      await api.atualizarUsuario({ ...outrosDados, senha });
      setMensagem('Usuário editado com sucesso');
    } catch (error) {
      console.error('Erro ao editar o usuário:', error.message);
      setMensagem('Erro ao editar o usuário');
    }
  };
  

  // Efeito que roda uma vez ao montar o componente, carregando os Usuarios
  //carrega os Usuarios imediatamente 
  useEffect(() => {
    const carregarUsuarios = async () => {
      try {
        const dados = await api.listarUsuarios(); // Corrigido para chamar listarUsuarios
        setUsuarios(dados);
      } catch (error) {
        console.error('Erro ao carregar os Usuarios:', error.message);
      }
    };

    carregarUsuarios();
  }, []);

  const excluirUsuario = async (id) => {
    try {
      // Chame o método adequado na API para excluir um usuário
      await api.excluirUsuario(id);
      const novaLista = usuarios.filter((usuario) => usuario.id !== id);
      setUsuarios(novaLista);
    } catch (error) {
      console.error('Erro ao excluir o usuário:', error.message);
    }
  };

  const editarUsuario = async (id) => {
    try {
      // Chame o método adequado na API para buscar um usuário por ID
      const usuarioSelecionado = await api.buscarUsuarioPorId(id);
      setItemSelecionado(usuarioSelecionado);
    } catch (error) {
      console.error('Erro ao carregar dados do usuário para edição:', error.message);
    }
  };

  // Retorno do JSX que representa a estrutura do componente
  return (
    <div className="classeCSS">
      <h1>Cadastro de Usuários</h1>
      {/* Componente de formulário que recebe campos, função de submissão, item selecionado e função de edição */}
      <Formulario
        campos={listaForm}
        onSubmit={enviarFormulario}
        itemSelecionado={itemSelecionado}
        onUpdate={editarFormulario}
      />
      {mensagem && <p>{mensagem}</p>} {/* Exibe mensagem se houver uma mensagem definida */}

      <h2>Usuarios Cadastrados</h2>
      {/* Componente de tabela que recebe dados, funções de exclusão e edição, e colunas */}
      <Tabela
        dados={usuarios}
        onExcluirItem={excluirUsuario}
        onEditarItem={editarUsuario}
        colunas={colunasUsuarios}
      />
    </div>
  );
};

// Exportação do componente para ser utilizado em outros lugares
export default CadastroUsuario;

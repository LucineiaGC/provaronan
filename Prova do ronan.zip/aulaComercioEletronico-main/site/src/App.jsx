import React from 'react';
import './App.css';
import CadastroUsuarios from './Pages/CadastroUsuarios';

function App() {
  return (
    <>
      <CadastroUsuarios />
      
    </>
  );
}

export default App;
